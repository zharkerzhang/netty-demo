
package example15;

public class Subscriber {
    public String name;
    public Address mailAddress;
}
