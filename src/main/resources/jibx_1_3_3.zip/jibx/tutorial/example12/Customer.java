
package example12;

public class Customer {
    public int customerNumber;
    public String firstName;
    public String lastName;
    public Address address;
    public String phone;
}
