
package example8;

public class Airport
{
    private String code;
    private String name;
    private String location;
}
