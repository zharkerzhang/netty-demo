
package example14;

public class Subscriber {
    public String name;
    public Address mailAddress;
}
