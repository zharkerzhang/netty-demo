
package example16;

public class Identity {
    public int customerNumber;
}
