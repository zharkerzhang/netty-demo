
package example21;

import java.util.HashMap;

public class Directory {
    private HashMap customerMap;
}
