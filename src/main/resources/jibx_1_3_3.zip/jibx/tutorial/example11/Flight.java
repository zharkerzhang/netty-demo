
package example11;

public class Flight
{
    private Carrier carrier;
    private int number;
    private String departure;
    private String arrival;
}
